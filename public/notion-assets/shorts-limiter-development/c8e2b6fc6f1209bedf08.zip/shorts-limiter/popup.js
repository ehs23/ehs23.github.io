const DEVELOPER_MODE = false;
const TRACKING_ENABLED = {
    shorts: true,
    reels: true
};

let currentState = null;
let settingsInitialized = false;


async function sendBackgroundMessage(message) {
    const response = await chrome.runtime.sendMessage(message);

    if (!response?.ok) {
        throw new Error(
            response?.error ?? "Background request failed"
        );
    }

    return response;
}


function renderPlatform(platform, state) {
    const count = state.counts[platform];
    const limit = state.activeLimits[platform];
    const remainingCount = Math.max(limit - count, 0);
    const limitReached = count >= limit;
    const progress = limit === 0
        ? 100
        : Math.min(count / limit * 100, 100);

    document.getElementById(`${platform}-count`).textContent =
        count;
    document.getElementById(`${platform}-current-limit`).textContent =
        limit;

    const progressBar =
        document.getElementById(`${platform}-progress-bar`);
    const progressTrack =
        document.getElementById(`${platform}-progress-track`);
    const remaining =
        document.getElementById(`${platform}-remaining`);
    const status =
        document.getElementById(`${platform}-status`);

    progressBar.style.width = `${progress}%`;
    progressTrack.setAttribute("aria-valuemax", limit);
    progressTrack.setAttribute("aria-valuenow", count);

    status.classList.toggle("is-blocked", limitReached);

    if (!TRACKING_ENABLED[platform]) {
        status.textContent = "연결 예정";
        remaining.textContent =
            "한도 설정은 저장됐고 Reels 감지는 다음 단계에서 연결돼.";
        return;
    }

    if (limitReached) {
        status.textContent = limit === 0
            ? "사용 안 함"
            : "제한 도달";
        remaining.textContent = limit === 0
            ? "오늘은 이 플랫폼의 숏폼을 차단해."
            : "오늘 한도를 모두 사용했어.";
        return;
    }

    status.textContent = "시청 가능";
    remaining.textContent =
        `오늘 ${remainingCount}개 더 볼 수 있어.`;
}


function renderSettings(state, force = false) {
    const pending = state.pendingLimits;
    const shortsInput =
        document.getElementById("shorts-limit-input");
    const reelsInput =
        document.getElementById("reels-limit-input");

    document.getElementById("current-limits").textContent =
        `오늘 적용 중 · Shorts ${state.activeLimits.shorts}개 · ` +
        `Reels ${state.activeLimits.reels}개`;

    if (!settingsInitialized || force) {
        shortsInput.value =
            pending?.shorts ?? state.activeLimits.shorts;
        reelsInput.value =
            pending?.reels ?? state.activeLimits.reels;
        settingsInitialized = true;
    }

    updateRangeOutputs();

    const pendingSummary =
        document.getElementById("pending-summary");

    if (pending === null) {
        pendingSummary.hidden = true;
        pendingSummary.textContent = "";
        return;
    }

    pendingSummary.hidden = false;
    pendingSummary.textContent =
        `${pending.effectiveDate}부터 · ` +
        `Shorts ${pending.shorts}개 · Reels ${pending.reels}개`;
}


function renderState(state, forceSettings = false) {
    currentState = state;

    renderPlatform("shorts", state);
    renderPlatform("reels", state);
    renderSettings(state, forceSettings);

    document.getElementById("date").textContent = state.date;
}


function updateRangeOutputs() {
    document.getElementById("shorts-limit-value").textContent =
        document.getElementById("shorts-limit-input").value;
    document.getElementById("reels-limit-value").textContent =
        document.getElementById("reels-limit-input").value;
}


async function refreshPopup(forceSettings = false) {
    try {
        const response = await sendBackgroundMessage({
            type: "GET_STATE"
        });

        renderState(response.state, forceSettings);
    } catch (error) {
        console.error(
            "[Shorts Limiter] Popup refresh failed:",
            error
        );

        document.getElementById("settings-result").textContent =
            "저장된 상태를 불러오지 못했어.";
    }
}


async function savePendingLimits() {
    const resultElement =
        document.getElementById("settings-result");
    const shorts = Number(
        document.getElementById("shorts-limit-input").value
    );
    const reels = Number(
        document.getElementById("reels-limit-input").value
    );

    try {
        const response = await sendBackgroundMessage({
            type: "SET_PENDING_LIMITS",
            shorts,
            reels
        });

        settingsInitialized = false;
        renderState(response.state, true);

        resultElement.textContent =
            `${response.state.pendingLimits.effectiveDate}부터 적용돼.`;
    } catch (error) {
        console.error(
            "[Shorts Limiter] Limit update failed:",
            error
        );

        resultElement.textContent =
            "내일 한도를 예약하지 못했어.";
    }
}


async function runDeveloperAction(type, successMessage) {
    const resultElement =
        document.getElementById("developer-result");

    try {
        const response = await sendBackgroundMessage({ type });

        renderState(response.state);
        resultElement.textContent = successMessage;
    } catch (error) {
        console.error(
            "[Shorts Limiter] Developer action failed:",
            error
        );

        resultElement.textContent =
            "오늘 상태를 변경하지 못했어.";
    }
}


function initializeDeveloperTools() {
    if (!DEVELOPER_MODE) {
        return;
    }

    document.getElementById("developer-tools").hidden = false;

    document
        .getElementById("reset-limit")
        .addEventListener("click", () => {
            runDeveloperAction(
                "DEV_RESET_TODAY",
                "Shorts와 Reels의 오늘 기록을 초기화했어."
            );
        });

    document
        .getElementById("fill-limit")
        .addEventListener("click", () => {
            runDeveloperAction(
                "DEV_FILL_TODAY",
                "두 플랫폼의 오늘 한도를 모두 채웠어."
            );
        });
}


document
    .getElementById("shorts-limit-input")
    .addEventListener("input", updateRangeOutputs);

document
    .getElementById("reels-limit-input")
    .addEventListener("input", updateRangeOutputs);

document
    .getElementById("save-limits")
    .addEventListener("click", savePendingLimits);


chrome.storage.onChanged.addListener((changes, areaName) => {
    if (
        areaName === "local" &&
        changes.limiterState
    ) {
        refreshPopup();
    }
});


initializeDeveloperTools();
refreshPopup(true);
