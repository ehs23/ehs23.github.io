const STORAGE_KEY = "limiterState";
const SCHEMA_VERSION = 2;
const MAX_LIMIT = 10;
const DEFAULT_LIMIT = 10;
const PLATFORMS = ["shorts", "reels"];

let stateQueue = Promise.resolve();


function formatLocalDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}


function getToday() {
    return formatLocalDate(new Date());
}


function getTomorrow() {
    const now = new Date();
    const tomorrow = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() + 1
    );

    return formatLocalDate(tomorrow);
}


function clampInteger(value, minimum, maximum, fallback) {
    if (!Number.isInteger(value)) {
        return fallback;
    }

    return Math.min(Math.max(value, minimum), maximum);
}


function sanitizeVideoIds(value) {
    if (!Array.isArray(value)) {
        return [];
    }

    return Array.from(
        new Set(
            value.filter((videoId) => (
                typeof videoId === "string" &&
                videoId.length > 0
            ))
        )
    ).slice(0, MAX_LIMIT);
}


function createDefaultState(today = getToday()) {
    return {
        schemaVersion: SCHEMA_VERSION,
        date: today,
        counts: {
            shorts: 0,
            reels: 0
        },
        watchedIds: {
            shorts: [],
            reels: []
        },
        activeLimits: {
            shorts: DEFAULT_LIMIT,
            reels: DEFAULT_LIMIT
        },
        pendingLimits: null
    };
}


function normalizePendingLimits(value) {
    if (
        value === null ||
        typeof value !== "object" ||
        typeof value.effectiveDate !== "string"
    ) {
        return null;
    }

    return {
        shorts: clampInteger(
            value.shorts,
            0,
            MAX_LIMIT,
            DEFAULT_LIMIT
        ),
        reels: clampInteger(
            value.reels,
            0,
            MAX_LIMIT,
            DEFAULT_LIMIT
        ),
        effectiveDate: value.effectiveDate
    };
}


function normalizeState(rawState, legacyState = {}) {
    const today = getToday();

    if (
        rawState === null ||
        typeof rawState !== "object"
    ) {
        const migratedState = createDefaultState(today);

        if (legacyState.date === today) {
            migratedState.counts.shorts = clampInteger(
                legacyState.count,
                0,
                MAX_LIMIT,
                0
            );
        }

        return migratedState;
    }

    const state = createDefaultState(today);

    state.date =
        typeof rawState.date === "string"
            ? rawState.date
            : today;

    for (const platform of PLATFORMS) {
        state.activeLimits[platform] = clampInteger(
            rawState.activeLimits?.[platform],
            0,
            MAX_LIMIT,
            DEFAULT_LIMIT
        );

        state.watchedIds[platform] = sanitizeVideoIds(
            rawState.watchedIds?.[platform]
        );

        const normalizedCount = clampInteger(
            rawState.counts?.[platform],
            0,
            state.activeLimits[platform],
            0
        );

        state.counts[platform] = Math.min(
            Math.max(
                normalizedCount,
                state.watchedIds[platform].length
            ),
            state.activeLimits[platform]
        );

        state.watchedIds[platform] =
            state.watchedIds[platform].slice(
                0,
                state.counts[platform]
            );
    }

    state.pendingLimits = normalizePendingLimits(
        rawState.pendingLimits
    );

    // 예약 날짜가 오늘이거나 이미 지났으면 오늘 한도로 승격
    if (
        state.pendingLimits !== null &&
        state.pendingLimits.effectiveDate <= today
    ) {
        state.activeLimits.shorts =
            state.pendingLimits.shorts;
        state.activeLimits.reels =
            state.pendingLimits.reels;
        state.pendingLimits = null;
    }

    // 날짜가 바뀌면 플랫폼별 카운트와 시청 ID를 함께 초기화
    if (state.date !== today) {
        state.date = today;
        state.counts.shorts = 0;
        state.counts.reels = 0;
        state.watchedIds.shorts = [];
        state.watchedIds.reels = [];
    }

    state.schemaVersion = SCHEMA_VERSION;

    return state;
}


function statesAreEqual(first, second) {
    return JSON.stringify(first) === JSON.stringify(second);
}


async function loadState() {
    const stored = await chrome.storage.local.get([
        STORAGE_KEY,
        "count",
        "date"
    ]);

    const state = normalizeState(
        stored[STORAGE_KEY],
        {
            count: stored.count,
            date: stored.date
        }
    );

    if (!statesAreEqual(stored[STORAGE_KEY], state)) {
        await chrome.storage.local.set({
            [STORAGE_KEY]: state
        });
    }

    return state;
}


async function saveState(state) {
    await chrome.storage.local.set({
        [STORAGE_KEY]: state
    });

    return state;
}


function getPlatformSnapshot(state, platform) {
    return {
        date: state.date,
        count: state.counts[platform],
        limit: state.activeLimits[platform],
        watchedIds: [...state.watchedIds[platform]]
    };
}


async function recordWatch(platform, videoId) {
    if (
        !PLATFORMS.includes(platform) ||
        typeof videoId !== "string" ||
        videoId.length === 0
    ) {
        throw new Error("Invalid watch record");
    }

    const state = await loadState();
    const watchedIds = state.watchedIds[platform];
    const existingIndex = watchedIds.indexOf(videoId);
    const legacyOffset = Math.max(
        state.counts[platform] - watchedIds.length,
        0
    );

    if (existingIndex !== -1) {
        return {
            status: "alreadyWatched",
            ordinal: legacyOffset + existingIndex + 1,
            platformState: getPlatformSnapshot(state, platform),
            state
        };
    }

    if (
        state.counts[platform] >=
        state.activeLimits[platform]
    ) {
        return {
            status: "limitReached",
            ordinal: null,
            platformState: getPlatformSnapshot(state, platform),
            state
        };
    }

    watchedIds.push(videoId);
    state.counts[platform] += 1;

    await saveState(state);

    return {
        status: "counted",
        ordinal: state.counts[platform],
        platformState: getPlatformSnapshot(state, platform),
        state
    };
}


async function setPendingLimits(shorts, reels) {
    const state = await loadState();

    state.pendingLimits = {
        shorts: clampInteger(
            shorts,
            0,
            MAX_LIMIT,
            state.activeLimits.shorts
        ),
        reels: clampInteger(
            reels,
            0,
            MAX_LIMIT,
            state.activeLimits.reels
        ),
        effectiveDate: getTomorrow()
    };

    await saveState(state);

    return state;
}


async function resetToday() {
    const state = await loadState();

    state.counts.shorts = 0;
    state.counts.reels = 0;
    state.watchedIds.shorts = [];
    state.watchedIds.reels = [];

    await saveState(state);

    return state;
}


async function fillToday() {
    const state = await loadState();

    state.counts.shorts = state.activeLimits.shorts;
    state.counts.reels = state.activeLimits.reels;
    state.watchedIds.shorts = [];
    state.watchedIds.reels = [];

    await saveState(state);

    return state;
}


async function handleMessage(message) {
    switch (message?.type) {
        case "GET_STATE":
            return {
                state: await loadState()
            };

        case "RECORD_WATCH":
            return await recordWatch(
                message.platform,
                message.videoId
            );

        case "SET_PENDING_LIMITS":
            return {
                state: await setPendingLimits(
                    message.shorts,
                    message.reels
                )
            };

        case "DEV_RESET_TODAY":
            return {
                state: await resetToday()
            };

        case "DEV_FILL_TODAY":
            return {
                state: await fillToday()
            };

        default:
            throw new Error("Unknown message type");
    }
}


function enqueueStateTask(task) {
    const result = stateQueue.then(task, task);

    stateQueue = result.catch(() => undefined);

    return result;
}


chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
        enqueueStateTask(() => handleMessage(message))
            .then((result) => {
                sendResponse({
                    ok: true,
                    ...result
                });
            })
            .catch((error) => {
                console.error(
                    "[Shorts Limiter] Background error:",
                    error
                );

                sendResponse({
                    ok: false,
                    error: error.message
                });
            });

        return true;
    }
);
