console.log("[Shorts Limiter] loaded — actual playback build 0.7.0");

const PLATFORM = "shorts";
const WATCH_THRESHOLD = 2000;
const PLAYBACK_SAMPLE_INTERVAL = 250;
const BLOCKER_ID = "shorts-limiter-blocker";
const COUNTER_ID = "shorts-limiter-counter";
const COUNTER_NUMBER_ID = "shorts-limiter-counter-number";
const COUNTER_PROGRESS_ID = "shorts-limiter-counter-progress";
const COUNTER_STATUS_ID = "shorts-limiter-counter-status";

let previousUrl = location.href;
let currentShortsId = null;
let watchTimer = null;
let playbackPauseTimer = null;
let blockedShortsId = null;
let pendingShortsId = null;
let pendingLocalCountWrite = null;
let currentViewNumber = null;
let displayedWatchedCount = 0;
let currentShortsLimit = 10;
let currentVideoAlreadyWatched = false;
let lastKnownDate = null;
let watchedPlaybackMs = 0;
let lastPlaybackSampleAt = null;
let lastVideoCurrentTime = null;
let watchProcessing = false;


// ========================================
// 백그라운드 상태 관리자 호출
// ========================================

async function sendBackgroundMessage(message) {
    const response = await chrome.runtime.sendMessage(message);

    if (!response?.ok) {
        throw new Error(
            response?.error ?? "Background request failed"
        );
    }

    return response;
}


async function getShortsState() {
    const response = await sendBackgroundMessage({
        type: "GET_STATE"
    });

    const state = response.state;

    return {
        date: state.date,
        count: state.counts.shorts,
        limit: state.activeLimits.shorts,
        watchedIds: state.watchedIds.shorts
    };
}


async function recordShortsWatch(shortsId) {
    return await sendBackgroundMessage({
        type: "RECORD_WATCH",
        platform: PLATFORM,
        videoId: shortsId
    });
}


// ========================================
// 현재 페이지와 Shorts ID 확인
// ========================================

function isShortsPage() {
    return location.pathname.startsWith("/shorts/");
}


function getShortsId() {
    if (!isShortsPage()) {
        return null;
    }

    const parts = location.pathname.split("/");

    return parts[2] || null;
}


// ========================================
// 시청 타이머
// ========================================

function cancelWatchTimer() {
    if (watchTimer === null) {
        return;
    }

    clearInterval(watchTimer);
    watchTimer = null;
    watchedPlaybackMs = 0;
    lastPlaybackSampleAt = null;
    lastVideoCurrentTime = null;
    watchProcessing = false;

    console.log(
        "[Shorts Limiter] Watch timer cancelled"
    );
}


// ========================================
// 차단 화면
// ========================================

function pauseShortsVideos() {
    document.querySelectorAll("video").forEach((video) => {
        video.pause();
    });
}


function createBlockerElement() {
    const blocker = document.createElement("div");
    const card = document.createElement("div");
    const label = document.createElement("p");
    const title = document.createElement("h1");
    const message = document.createElement("p");
    const exitLink = document.createElement("a");

    blocker.id = BLOCKER_ID;

    Object.assign(blocker.style, {
        position: "fixed",
        inset: "0",
        zIndex: "2147483647",
        display: "grid",
        placeItems: "center",
        background: "rgba(10, 10, 12, 0.98)",
        color: "#ffffff"
    });

    card.className = "shorts-limiter-card";
    card.setAttribute("role", "dialog");
    card.setAttribute("aria-modal", "true");

    label.className = "shorts-limiter-label";
    label.textContent = "YOUTUBE SHORTS LIMIT";

    title.textContent = "오늘은 여기까지!";

    message.textContent = currentShortsLimit === 0
        ? "오늘의 Shorts 한도가 0개로 설정되어 있어."
        : `오늘 볼 수 있는 Shorts ${currentShortsLimit}개를 모두 봤어. ` +
          "이미 본 영상은 다시 볼 수 있지만 새 영상은 내일 보자.";

    exitLink.href = "/";
    exitLink.textContent = "YouTube 홈으로 나가기";

    card.append(label, title, message, exitLink);
    blocker.appendChild(card);

    return blocker;
}


function showBlocker(shortsId = getShortsId()) {
    const countAtBlock = displayedWatchedCount;

    blockedShortsId = shortsId;

    cancelWatchTimer();
    removeCounterBadge();
    pauseShortsVideos();

    document.documentElement.classList.add(
        "shorts-limiter-blocked"
    );

    if (document.getElementById(BLOCKER_ID) === null) {
        const blocker = createBlockerElement();
        const blockerParent = document.body ?? document.documentElement;

        blockerParent.appendChild(blocker);
    }

    if (playbackPauseTimer === null) {
        playbackPauseTimer = setInterval(
            pauseShortsVideos,
            500
        );
    }

    console.log(
        `[Shorts Limiter] Blocked: ${countAtBlock} / ${currentShortsLimit}`
    );
}


function removeBlocker() {
    blockedShortsId = null;

    document
        .getElementById(BLOCKER_ID)
        ?.remove();

    document.documentElement.classList.remove(
        "shorts-limiter-blocked"
    );

    if (playbackPauseTimer !== null) {
        clearInterval(playbackPauseTimer);
        playbackPauseTimer = null;
    }
}


// ========================================
// Shorts 버튼 영역 옆 현재 순번 표시
// ========================================

function createCounterBadge() {
    const badge = document.createElement("div");
    const label = document.createElement("span");
    const number = document.createElement("strong");
    const progress = document.createElement("small");
    const status = document.createElement("em");

    badge.id = COUNTER_ID;
    badge.setAttribute("aria-live", "polite");

    label.textContent = "현재 시청 순번";

    number.id = COUNTER_NUMBER_ID;
    progress.id = COUNTER_PROGRESS_ID;
    status.id = COUNTER_STATUS_ID;

    badge.append(label, number, progress, status);

    return badge;
}


function positionCounterBadge() {
    const badge = document.getElementById(COUNTER_ID);

    if (badge === null) {
        return;
    }

    const actionAreas = Array.from(
        document.querySelectorAll(
            "ytd-reel-video-renderer #actions"
        )
    );

    const visibleActions = actionAreas.find((element) => {
        const rect = element.getBoundingClientRect();

        return (
            rect.width > 0 &&
            rect.height > 0 &&
            rect.bottom > 0 &&
            rect.top < window.innerHeight
        );
    });

    if (visibleActions === undefined) {
        badge.style.left = "auto";
        badge.style.right = "28px";
        badge.style.top = "104px";
        return;
    }

    const actionsRect = visibleActions.getBoundingClientRect();
    const badgeHeight = badge.offsetHeight || 104;

    badge.style.left = `${Math.round(actionsRect.left)}px`;
    badge.style.right = "auto";
    badge.style.top =
        `${Math.max(16, Math.round(actionsRect.top - badgeHeight - 16))}px`;
}


function showCounterBadge(
    viewNumber,
    watchedCount,
    limit,
    alreadyWatched = false
) {
    if (!isShortsPage() || blockedShortsId !== null) {
        return;
    }

    currentViewNumber = viewNumber;
    displayedWatchedCount = watchedCount;
    currentShortsLimit = limit;
    currentVideoAlreadyWatched = alreadyWatched;

    let badge = document.getElementById(COUNTER_ID);

    if (badge === null) {
        badge = createCounterBadge();

        const badgeParent = document.body ?? document.documentElement;
        badgeParent.appendChild(badge);
    }

    document.getElementById(COUNTER_NUMBER_ID).textContent =
        `${currentViewNumber}번째`;

    document.getElementById(COUNTER_PROGRESS_ID).textContent =
        `${displayedWatchedCount} / ${currentShortsLimit} 고유 영상`;

    const statusElement =
        document.getElementById(COUNTER_STATUS_ID);

    statusElement.textContent = alreadyWatched
        ? "이미 본 영상 · 카운트 유지"
        : "새 영상";

    statusElement.classList.toggle(
        "is-repeat",
        alreadyWatched
    );

    positionCounterBadge();
}


function removeCounterBadge() {
    document
        .getElementById(COUNTER_ID)
        ?.remove();

    currentViewNumber = null;
    displayedWatchedCount = 0;
    currentVideoAlreadyWatched = false;
}


// ========================================
// 실제 재생 중인 Shorts 영상 찾기
// ========================================

function getActiveShortsVideo() {
    const renderers = Array.from(
        document.querySelectorAll("ytd-reel-video-renderer")
    );

    const visibleRenderer = renderers.find((renderer) => {
        const rect = renderer.getBoundingClientRect();

        return (
            rect.width > 0 &&
            rect.height > 0 &&
            rect.bottom > 0 &&
            rect.top < window.innerHeight
        );
    });

    const rendererVideo = visibleRenderer?.querySelector("video");

    if (rendererVideo) {
        return rendererVideo;
    }

    return Array.from(document.querySelectorAll("video"))
        .find((video) => {
            const rect = video.getBoundingClientRect();

            return (
                rect.width > 0 &&
                rect.height > 0 &&
                rect.bottom > 0 &&
                rect.top < window.innerHeight
            );
        }) ?? null;
}


function isVideoActivelyPlaying(video) {
    return (
        video !== null &&
        !video.paused &&
        !video.ended &&
        !video.seeking &&
        video.readyState >= 2 &&
        document.visibilityState === "visible"
    );
}


async function completeShortsWatch(shortsId) {
    const expectedCount = displayedWatchedCount + 1;
    pendingLocalCountWrite = expectedCount;

    const result = await recordShortsWatch(shortsId);
    const platformState = result.platformState;

    currentShortsLimit = platformState.limit;

    if (result.status !== "counted") {
        pendingLocalCountWrite = null;
    } else {
        setTimeout(() => {
            if (pendingLocalCountWrite === expectedCount) {
                pendingLocalCountWrite = null;
            }
        }, 1000);
    }

    if (getShortsId() !== shortsId) {
        return;
    }

    if (result.status === "limitReached") {
        displayedWatchedCount = platformState.count;
        showBlocker(shortsId);
        return;
    }

    const alreadyWatched =
        result.status === "alreadyWatched";

    showCounterBadge(
        result.ordinal,
        platformState.count,
        platformState.limit,
        alreadyWatched
    );

    console.log(
        alreadyWatched
            ? `[Shorts Limiter] Already watched: ${shortsId}`
            : `[Shorts Limiter] Watched: ${shortsId}`
    );

    console.log(
        `[Shorts Limiter] Count: ${platformState.count} / ${platformState.limit}`
    );
}


// ========================================
// 새로운 Shorts 실제 재생시간 측정 시작
// ========================================

function startWatching(shortsId) {
    cancelWatchTimer();

    currentShortsId = shortsId;
    watchedPlaybackMs = 0;
    lastPlaybackSampleAt = null;
    lastVideoCurrentTime = null;

    console.log(
        "[Shorts Limiter] Waiting for actual playback:",
        shortsId
    );

    watchTimer = setInterval(() => {
        if (
            getShortsId() !== shortsId ||
            currentShortsId !== shortsId
        ) {
            cancelWatchTimer();
            return;
        }

        const video = getActiveShortsVideo();
        const sampleAt = performance.now();
        const videoCurrentTime = video?.currentTime ?? null;

        if (!isVideoActivelyPlaying(video)) {
            lastPlaybackSampleAt = sampleAt;
            lastVideoCurrentTime = videoCurrentTime;
            return;
        }

        if (
            lastPlaybackSampleAt === null ||
            lastVideoCurrentTime === null
        ) {
            lastPlaybackSampleAt = sampleAt;
            lastVideoCurrentTime = videoCurrentTime;
            return;
        }

        const wallDeltaMs = sampleAt - lastPlaybackSampleAt;
        const mediaDeltaSeconds =
            videoCurrentTime - lastVideoCurrentTime;
        const playbackRate = Math.max(video.playbackRate || 1, 0.25);
        const maximumExpectedMediaDelta =
            wallDeltaMs / 1000 * playbackRate * 3 + 0.35;

        lastPlaybackSampleAt = sampleAt;
        lastVideoCurrentTime = videoCurrentTime;

        // 일시정지·버퍼링·탐색 점프는 실제 재생시간에 포함하지 않음
        if (
            mediaDeltaSeconds <= 0 ||
            mediaDeltaSeconds > maximumExpectedMediaDelta
        ) {
            return;
        }

        watchedPlaybackMs += wallDeltaMs;

        if (
            watchedPlaybackMs < WATCH_THRESHOLD ||
            watchProcessing
        ) {
            return;
        }

        clearInterval(watchTimer);
        watchTimer = null;
        watchProcessing = true;

        completeShortsWatch(shortsId)
            .catch((error) => {
                console.error(
                    "[Shorts Limiter] Watch completion failed:",
                    error
                );
            })
            .finally(() => {
                watchProcessing = false;
                watchedPlaybackMs = 0;
                lastPlaybackSampleAt = null;
                lastVideoCurrentTime = null;
            });
    }, PLAYBACK_SAMPLE_INTERVAL);
}


// ========================================
// 현재 페이지 처리
// ========================================

async function handleCurrentPage(prefetchedState = null) {
    const shortsId = getShortsId();

    if (shortsId === null) {
        cancelWatchTimer();
        currentShortsId = null;
        pendingShortsId = null;
        removeBlocker();
        removeCounterBadge();
        return;
    }

    if (document.visibilityState !== "visible") {
        cancelWatchTimer();
        currentShortsId = null;
        return;
    }

    if (shortsId === currentShortsId) {
        if (blockedShortsId === shortsId) {
            showBlocker(shortsId);
        } else if (
            currentViewNumber !== null &&
            document.getElementById(COUNTER_ID) === null
        ) {
            showCounterBadge(
                currentViewNumber,
                displayedWatchedCount,
                currentShortsLimit,
                currentVideoAlreadyWatched
            );
        }

        return;
    }

    if (shortsId === pendingShortsId) {
        return;
    }

    cancelWatchTimer();
    pendingShortsId = shortsId;

    try {
        const state = prefetchedState ?? await getShortsState();

        if (getShortsId() !== shortsId) {
            return;
        }

        lastKnownDate = state.date;

        currentShortsLimit = state.limit;
        displayedWatchedCount = state.count;

        const existingIndex =
            state.watchedIds.indexOf(shortsId);

        // 이미 본 영상은 한도에 도달했어도 다시 볼 수 있음
        if (existingIndex !== -1) {
            const legacyOffset = Math.max(
                state.count - state.watchedIds.length,
                0
            );

            currentShortsId = shortsId;
            removeBlocker();

            showCounterBadge(
                legacyOffset + existingIndex + 1,
                state.count,
                state.limit,
                true
            );

            console.log(
                "[Shorts Limiter] Already watched:",
                shortsId
            );

            return;
        }

        if (state.count >= state.limit) {
            currentShortsId = shortsId;
            removeCounterBadge();
            showBlocker(shortsId);
            return;
        }

        removeBlocker();

        showCounterBadge(
            state.count + 1,
            state.count,
            state.limit,
            false
        );

        startWatching(shortsId);
    } finally {
        if (pendingShortsId === shortsId) {
            pendingShortsId = null;
        }
    }
}


function requestPageHandling() {
    handleCurrentPage().catch((error) => {
        console.error(
            "[Shorts Limiter] Page handling failed:",
            error
        );
    });
}


// ========================================
// 초기화와 YouTube SPA 이동 감지
// ========================================

async function initialize() {
    const state = await getShortsState();

    currentShortsLimit = state.limit;
    displayedWatchedCount = state.count;
    lastKnownDate = state.date;

    console.log(
        `[Shorts Limiter] Stored Shorts: ${state.count} / ${state.limit}`
    );

    console.log(
        "[Shorts Limiter] Stored date:",
        state.date
    );

    requestPageHandling();
}


initialize().catch((error) => {
    console.error(
        "[Shorts Limiter] Initialization failed:",
        error
    );
});


async function handleNavigationChange() {
    const state = await getShortsState();
    const dateChanged =
        lastKnownDate !== null &&
        lastKnownDate !== state.date;

    lastKnownDate = state.date;
    currentShortsLimit = state.limit;
    displayedWatchedCount = state.count;

    if (dateChanged) {
        currentShortsId = null;
        pendingShortsId = null;

        cancelWatchTimer();
        removeBlocker();
        removeCounterBadge();
    }

    await handleCurrentPage(
        isShortsPage() ? state : null
    );
}


function requestNavigationHandling() {
    handleNavigationChange().catch((error) => {
        console.error(
            "[Shorts Limiter] Navigation handling failed:",
            error
        );
    });
}


function detectNavigation() {
    const currentUrl = location.href;
    const detectedShortsId = getShortsId();
    const urlChanged = currentUrl !== previousUrl;
    const shortsChanged = detectedShortsId !== currentShortsId;

    positionCounterBadge();

    if (!urlChanged && !shortsChanged) {
        if (
            blockedShortsId !== null &&
            blockedShortsId === detectedShortsId &&
            document.getElementById(BLOCKER_ID) === null
        ) {
            showBlocker(detectedShortsId);
        }

        return;
    }

    if (urlChanged) {
        previousUrl = currentUrl;

        console.log(
            "[Shorts Limiter] URL changed:",
            currentUrl
        );

        requestNavigationHandling();
        return;
    }

    requestPageHandling();
}


setInterval(detectNavigation, 250);


document.addEventListener(
    "yt-navigate-finish",
    detectNavigation
);

window.addEventListener(
    "popstate",
    detectNavigation
);


document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
        const wasWaiting = watchTimer !== null;

        cancelWatchTimer();

        if (wasWaiting) {
            currentShortsId = null;
        }

        return;
    }

    requestPageHandling();
});


// ========================================
// 팝업·다른 탭의 상태 변경 즉시 반영
// ========================================

chrome.storage.onChanged.addListener((changes, areaName) => {
    const nextState = changes.limiterState?.newValue;

    if (
        areaName !== "local" ||
        nextState === undefined
    ) {
        return;
    }

    const nextCount = nextState.counts?.shorts;
    const nextLimit = nextState.activeLimits?.shorts;
    const nextWatchedIds = nextState.watchedIds?.shorts ?? [];

    if (!Number.isInteger(nextCount) || !Number.isInteger(nextLimit)) {
        return;
    }

    currentShortsLimit = nextLimit;

    if (nextCount === pendingLocalCountWrite) {
        pendingLocalCountWrite = null;
        return;
    }

    const shortsId = getShortsId();
    const currentBecameWatched =
        shortsId !== null &&
        nextWatchedIds.includes(shortsId);

    if (
        nextCount === 0 ||
        nextCount >= nextLimit ||
        (currentBecameWatched && watchTimer !== null)
    ) {
        cancelWatchTimer();
        currentShortsId = null;
        pendingShortsId = null;
        removeCounterBadge();

        if (nextCount < nextLimit || currentBecameWatched) {
            removeBlocker();
        }
    }

    requestPageHandling();
});
