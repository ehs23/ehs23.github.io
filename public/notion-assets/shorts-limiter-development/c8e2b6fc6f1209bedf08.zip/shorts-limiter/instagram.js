console.log("[Shorts Limiter] Instagram Reels loaded — build 0.7.1");

const PLATFORM = "reels";
const WATCH_THRESHOLD = 2000;
const PLAYBACK_SAMPLE_INTERVAL = 250;
const BLOCKER_ID = "shorts-limiter-blocker";
const COUNTER_ID = "shorts-limiter-counter";
const COUNTER_NUMBER_ID = "shorts-limiter-counter-number";
const COUNTER_PROGRESS_ID = "shorts-limiter-counter-progress";
const COUNTER_STATUS_ID = "shorts-limiter-counter-status";

let previousUrl = location.href;
let currentReelId = null;
let pendingReelId = null;
let blockedReelId = null;
let watchTimer = null;
let playbackPauseTimer = null;
let pendingLocalCountWrite = null;
let currentViewNumber = null;
let displayedWatchedCount = 0;
let currentReelsLimit = 10;
let currentVideoAlreadyWatched = false;
let lastKnownDate = null;
let watchedPlaybackMs = 0;
let lastPlaybackSampleAt = null;
let lastVideoCurrentTime = null;
let watchProcessing = false;


async function sendBackgroundMessage(message) {
    const response = await chrome.runtime.sendMessage(message);

    if (!response?.ok) {
        throw new Error(
            response?.error ?? "Background request failed"
        );
    }

    return response;
}


async function getReelsState() {
    const response = await sendBackgroundMessage({
        type: "GET_STATE"
    });

    const state = response.state;

    return {
        date: state.date,
        count: state.counts.reels,
        limit: state.activeLimits.reels,
        watchedIds: state.watchedIds.reels
    };
}


async function recordReelWatch(reelId) {
    return await sendBackgroundMessage({
        type: "RECORD_WATCH",
        platform: PLATFORM,
        videoId: reelId
    });
}


function isReelPage() {
    return /^\/reels?\/[^/]+/.test(location.pathname);
}


function getReelId() {
    if (!isReelPage()) {
        return null;
    }

    const match = location.pathname.match(/^\/reels?\/([^/]+)/);

    return match?.[1] ?? null;
}


function cancelWatchTimer() {
    if (watchTimer === null) {
        return;
    }

    clearInterval(watchTimer);
    watchTimer = null;
    watchedPlaybackMs = 0;
    lastPlaybackSampleAt = null;
    lastVideoCurrentTime = null;
    watchProcessing = false;

    console.log(
        "[Shorts Limiter] Reels watch timer cancelled"
    );
}


function getActiveReelVideo() {
    return Array.from(document.querySelectorAll("video"))
        .filter((video) => {
            const rect = video.getBoundingClientRect();

            return (
                rect.width > 0 &&
                rect.height > 0 &&
                rect.bottom > 0 &&
                rect.top < window.innerHeight
            );
        })
        .sort((first, second) => {
            const firstRect = first.getBoundingClientRect();
            const secondRect = second.getBoundingClientRect();
            const firstArea = firstRect.width * firstRect.height;
            const secondArea = secondRect.width * secondRect.height;

            return secondArea - firstArea;
        })[0] ?? null;
}


function isVideoActivelyPlaying(video) {
    return (
        video !== null &&
        !video.paused &&
        !video.ended &&
        !video.seeking &&
        video.readyState >= 2 &&
        document.visibilityState === "visible"
    );
}


function pauseReelVideos() {
    document.querySelectorAll("video").forEach((video) => {
        video.pause();
    });
}


function createBlockerElement() {
    const blocker = document.createElement("div");
    const card = document.createElement("div");
    const label = document.createElement("p");
    const title = document.createElement("h1");
    const message = document.createElement("p");
    const exitLink = document.createElement("a");

    blocker.id = BLOCKER_ID;

    Object.assign(blocker.style, {
        position: "fixed",
        inset: "0",
        zIndex: "2147483647",
        display: "grid",
        placeItems: "center",
        background: "rgba(10, 10, 12, 0.98)",
        color: "#ffffff"
    });

    card.className = "shorts-limiter-card";
    card.setAttribute("role", "dialog");
    card.setAttribute("aria-modal", "true");

    label.className = "shorts-limiter-label";
    label.textContent = "INSTAGRAM REELS LIMIT";
    title.textContent = "오늘은 여기까지!";
    message.textContent = currentReelsLimit === 0
        ? "오늘의 Reels 한도가 0개로 설정되어 있어."
        : `오늘 볼 수 있는 Reels ${currentReelsLimit}개를 모두 봤어. ` +
          "이미 본 영상은 다시 볼 수 있지만 새 영상은 내일 보자.";

    exitLink.href = "/";
    exitLink.textContent = "Instagram 홈으로 나가기";

    card.append(label, title, message, exitLink);
    blocker.appendChild(card);

    return blocker;
}


function showBlocker(reelId = getReelId()) {
    const countAtBlock = displayedWatchedCount;

    blockedReelId = reelId;
    cancelWatchTimer();
    removeCounterBadge();
    pauseReelVideos();

    document.documentElement.classList.add(
        "shorts-limiter-blocked"
    );

    if (document.getElementById(BLOCKER_ID) === null) {
        const blocker = createBlockerElement();
        const blockerParent = document.body ?? document.documentElement;

        blockerParent.appendChild(blocker);
    }

    if (playbackPauseTimer === null) {
        playbackPauseTimer = setInterval(
            pauseReelVideos,
            500
        );
    }

    console.log(
        `[Shorts Limiter] Reels blocked: ${countAtBlock} / ${currentReelsLimit}`
    );
}


function removeBlocker() {
    blockedReelId = null;

    document
        .getElementById(BLOCKER_ID)
        ?.remove();

    document.documentElement.classList.remove(
        "shorts-limiter-blocked"
    );

    if (playbackPauseTimer !== null) {
        clearInterval(playbackPauseTimer);
        playbackPauseTimer = null;
    }
}


function createCounterBadge() {
    const badge = document.createElement("div");
    const label = document.createElement("span");
    const number = document.createElement("strong");
    const progress = document.createElement("small");
    const status = document.createElement("em");

    badge.id = COUNTER_ID;
    badge.setAttribute("aria-live", "polite");

    label.textContent = "현재 Reels 순번";
    number.id = COUNTER_NUMBER_ID;
    progress.id = COUNTER_PROGRESS_ID;
    status.id = COUNTER_STATUS_ID;

    badge.append(label, number, progress, status);

    return badge;
}


function positionCounterBadge() {
    const badge = document.getElementById(COUNTER_ID);

    if (badge === null) {
        return;
    }

    const video = getActiveReelVideo();

    if (video === null) {
        badge.style.left = "auto";
        badge.style.right = "28px";
        badge.style.top = "104px";
        return;
    }

    const videoRect = video.getBoundingClientRect();
    const badgeWidth = badge.offsetWidth || 154;
    const preferredLeft = videoRect.right + 16;
    const fitsOnRight =
        preferredLeft + badgeWidth <= window.innerWidth - 16;

    badge.style.left = fitsOnRight
        ? `${Math.round(preferredLeft)}px`
        : `${Math.max(16, Math.round(videoRect.left - badgeWidth - 16))}px`;
    badge.style.right = "auto";
    badge.style.top = `${Math.max(16, Math.round(videoRect.top + 18))}px`;
}


function showCounterBadge(
    viewNumber,
    watchedCount,
    limit,
    alreadyWatched = false
) {
    if (!isReelPage() || blockedReelId !== null) {
        return;
    }

    currentViewNumber = viewNumber;
    displayedWatchedCount = watchedCount;
    currentReelsLimit = limit;
    currentVideoAlreadyWatched = alreadyWatched;

    let badge = document.getElementById(COUNTER_ID);

    if (badge === null) {
        badge = createCounterBadge();

        const badgeParent = document.body ?? document.documentElement;
        badgeParent.appendChild(badge);
    }

    document.getElementById(COUNTER_NUMBER_ID).textContent =
        `${currentViewNumber}번째`;
    document.getElementById(COUNTER_PROGRESS_ID).textContent =
        `${displayedWatchedCount} / ${currentReelsLimit} 고유 영상`;

    const statusElement =
        document.getElementById(COUNTER_STATUS_ID);

    statusElement.textContent = alreadyWatched
        ? "이미 본 영상 · 카운트 유지"
        : "새 영상";
    statusElement.classList.toggle(
        "is-repeat",
        alreadyWatched
    );

    positionCounterBadge();
}


function removeCounterBadge() {
    document
        .getElementById(COUNTER_ID)
        ?.remove();

    currentViewNumber = null;
    displayedWatchedCount = 0;
    currentVideoAlreadyWatched = false;
}


async function completeReelWatch(reelId) {
    const expectedCount = displayedWatchedCount + 1;
    pendingLocalCountWrite = expectedCount;

    const result = await recordReelWatch(reelId);
    const platformState = result.platformState;

    currentReelsLimit = platformState.limit;

    if (result.status !== "counted") {
        pendingLocalCountWrite = null;
    } else {
        setTimeout(() => {
            if (pendingLocalCountWrite === expectedCount) {
                pendingLocalCountWrite = null;
            }
        }, 1000);
    }

    if (getReelId() !== reelId) {
        return;
    }

    if (result.status === "limitReached") {
        displayedWatchedCount = platformState.count;
        showBlocker(reelId);
        return;
    }

    const alreadyWatched =
        result.status === "alreadyWatched";

    showCounterBadge(
        result.ordinal,
        platformState.count,
        platformState.limit,
        alreadyWatched
    );

    console.log(
        alreadyWatched
            ? `[Shorts Limiter] Reel already watched: ${reelId}`
            : `[Shorts Limiter] Reel watched: ${reelId}`
    );
}


function startWatching(reelId) {
    cancelWatchTimer();

    currentReelId = reelId;
    watchedPlaybackMs = 0;
    lastPlaybackSampleAt = null;
    lastVideoCurrentTime = null;

    console.log(
        "[Shorts Limiter] Waiting for actual Reel playback:",
        reelId
    );

    watchTimer = setInterval(() => {
        if (
            getReelId() !== reelId ||
            currentReelId !== reelId
        ) {
            cancelWatchTimer();
            return;
        }

        const video = getActiveReelVideo();
        const sampleAt = performance.now();
        const videoCurrentTime = video?.currentTime ?? null;

        if (!isVideoActivelyPlaying(video)) {
            lastPlaybackSampleAt = sampleAt;
            lastVideoCurrentTime = videoCurrentTime;
            return;
        }

        if (
            lastPlaybackSampleAt === null ||
            lastVideoCurrentTime === null
        ) {
            lastPlaybackSampleAt = sampleAt;
            lastVideoCurrentTime = videoCurrentTime;
            return;
        }

        const wallDeltaMs = sampleAt - lastPlaybackSampleAt;
        const mediaDeltaSeconds =
            videoCurrentTime - lastVideoCurrentTime;
        const playbackRate = Math.max(video.playbackRate || 1, 0.25);
        const maximumExpectedMediaDelta =
            wallDeltaMs / 1000 * playbackRate * 3 + 0.35;

        lastPlaybackSampleAt = sampleAt;
        lastVideoCurrentTime = videoCurrentTime;

        if (
            mediaDeltaSeconds <= 0 ||
            mediaDeltaSeconds > maximumExpectedMediaDelta
        ) {
            return;
        }

        watchedPlaybackMs += wallDeltaMs;

        if (
            watchedPlaybackMs < WATCH_THRESHOLD ||
            watchProcessing
        ) {
            return;
        }

        clearInterval(watchTimer);
        watchTimer = null;
        watchProcessing = true;

        completeReelWatch(reelId)
            .catch((error) => {
                console.error(
                    "[Shorts Limiter] Reel completion failed:",
                    error
                );
            })
            .finally(() => {
                watchProcessing = false;
                watchedPlaybackMs = 0;
                lastPlaybackSampleAt = null;
                lastVideoCurrentTime = null;
            });
    }, PLAYBACK_SAMPLE_INTERVAL);
}


async function handleCurrentPage(prefetchedState = null) {
    const reelId = getReelId();

    if (reelId === null) {
        cancelWatchTimer();
        currentReelId = null;
        pendingReelId = null;
        removeBlocker();
        removeCounterBadge();
        return;
    }

    if (document.visibilityState !== "visible") {
        cancelWatchTimer();
        currentReelId = null;
        return;
    }

    if (reelId === currentReelId) {
        if (blockedReelId === reelId) {
            showBlocker(reelId);
        } else if (
            currentViewNumber !== null &&
            document.getElementById(COUNTER_ID) === null
        ) {
            showCounterBadge(
                currentViewNumber,
                displayedWatchedCount,
                currentReelsLimit,
                currentVideoAlreadyWatched
            );
        }

        return;
    }

    if (reelId === pendingReelId) {
        return;
    }

    cancelWatchTimer();
    pendingReelId = reelId;

    try {
        const state = prefetchedState ?? await getReelsState();

        if (getReelId() !== reelId) {
            return;
        }

        lastKnownDate = state.date;
        currentReelsLimit = state.limit;
        displayedWatchedCount = state.count;

        const existingIndex = state.watchedIds.indexOf(reelId);

        if (existingIndex !== -1) {
            const legacyOffset = Math.max(
                state.count - state.watchedIds.length,
                0
            );

            currentReelId = reelId;
            removeBlocker();
            showCounterBadge(
                legacyOffset + existingIndex + 1,
                state.count,
                state.limit,
                true
            );
            return;
        }

        if (state.count >= state.limit) {
            currentReelId = reelId;
            removeCounterBadge();
            showBlocker(reelId);
            return;
        }

        removeBlocker();
        showCounterBadge(
            state.count + 1,
            state.count,
            state.limit,
            false
        );
        startWatching(reelId);
    } finally {
        if (pendingReelId === reelId) {
            pendingReelId = null;
        }
    }
}


function requestPageHandling() {
    handleCurrentPage().catch((error) => {
        console.error(
            "[Shorts Limiter] Reels page handling failed:",
            error
        );
    });
}


async function handleNavigationChange() {
    const state = await getReelsState();
    const dateChanged =
        lastKnownDate !== null &&
        lastKnownDate !== state.date;

    lastKnownDate = state.date;
    currentReelsLimit = state.limit;
    displayedWatchedCount = state.count;

    if (dateChanged) {
        currentReelId = null;
        pendingReelId = null;
        cancelWatchTimer();
        removeBlocker();
        removeCounterBadge();
    }

    await handleCurrentPage(
        isReelPage() ? state : null
    );
}


function requestNavigationHandling() {
    handleNavigationChange().catch((error) => {
        console.error(
            "[Shorts Limiter] Reels navigation failed:",
            error
        );
    });
}


function detectNavigation() {
    const currentUrl = location.href;
    const detectedReelId = getReelId();
    const urlChanged = currentUrl !== previousUrl;
    const reelChanged = detectedReelId !== currentReelId;

    positionCounterBadge();

    if (!urlChanged && !reelChanged) {
        if (
            blockedReelId !== null &&
            blockedReelId === detectedReelId &&
            document.getElementById(BLOCKER_ID) === null
        ) {
            showBlocker(detectedReelId);
        }

        return;
    }

    if (urlChanged) {
        previousUrl = currentUrl;
        console.log(
            "[Shorts Limiter] Instagram URL changed:",
            currentUrl
        );
        requestNavigationHandling();
        return;
    }

    requestPageHandling();
}


async function initialize() {
    const state = await getReelsState();

    currentReelsLimit = state.limit;
    displayedWatchedCount = state.count;
    lastKnownDate = state.date;

    console.log(
        `[Shorts Limiter] Stored Reels: ${state.count} / ${state.limit}`
    );

    requestPageHandling();
}


initialize().catch((error) => {
    console.error(
        "[Shorts Limiter] Reels initialization failed:",
        error
    );
});


setInterval(detectNavigation, 250);
window.addEventListener("popstate", detectNavigation);


document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
        const wasWaiting = watchTimer !== null;

        cancelWatchTimer();

        if (wasWaiting) {
            currentReelId = null;
        }

        return;
    }

    requestPageHandling();
});


chrome.storage.onChanged.addListener((changes, areaName) => {
    const nextState = changes.limiterState?.newValue;

    if (
        areaName !== "local" ||
        nextState === undefined
    ) {
        return;
    }

    const nextCount = nextState.counts?.reels;
    const nextLimit = nextState.activeLimits?.reels;
    const nextWatchedIds = nextState.watchedIds?.reels ?? [];

    if (!Number.isInteger(nextCount) || !Number.isInteger(nextLimit)) {
        return;
    }

    currentReelsLimit = nextLimit;

    if (nextCount === pendingLocalCountWrite) {
        pendingLocalCountWrite = null;
        return;
    }

    const reelId = getReelId();
    const currentBecameWatched =
        reelId !== null &&
        nextWatchedIds.includes(reelId);

    if (
        nextCount === 0 ||
        nextCount >= nextLimit ||
        (currentBecameWatched && watchTimer !== null)
    ) {
        cancelWatchTimer();
        currentReelId = null;
        pendingReelId = null;
        removeCounterBadge();

        if (nextCount < nextLimit || currentBecameWatched) {
            removeBlocker();
        }
    }

    requestPageHandling();
});
